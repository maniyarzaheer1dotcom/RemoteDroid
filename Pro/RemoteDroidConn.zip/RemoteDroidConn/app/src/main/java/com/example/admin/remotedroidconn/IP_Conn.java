package com.example.admin.remotedroidconn;

/**
 * Created by Admin on 10/02/2018.
 */

public class IP_Conn {

    public static  String ip_addr;


    public static void setIp_addr(String ip_addr)
    {
        IP_Conn.ip_addr=ip_addr;
    }

    public static String getIp_addr()
    {
        return  ip_addr;
    }



}
